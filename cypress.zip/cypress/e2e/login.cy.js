describe('Тестирование входа на сайт', () => {
  beforeEach(() => {
    cy.visit('https://login.qa.studio')
  })

  it('Успешный вход с валидными данными', () => {
    cy.get('#mail')
      .type('german@dolnikov.ru')
      .should('have.value', 'german@dolnikov.ru')

    cy.get('#pass')
      .type('qa_one_love1')
      .should('have.value', 'qa_one_love1')

    cy.get('#loginButton').click()

    cy.contains('Авторизация прошла успешно')
      .should('be.visible')

    cy.get('#exitMessageButton > .exitIcon').click()
  })
})

describe('Проверка логики восстановления пароля', () => {
  beforeEach(() => {
    cy.visit('https://login.qa.studio')
  })

  it('Открывает форму “Забыли пароль” и показывает уведомление', () => {
    cy.contains('Забыли пароль').click()

    cy.get('#mailForgot')
      .should('be.visible')
      .type('test@example.com')

    cy.get('#restoreEmailButton').click()

    cy.contains('Успешно отправили пароль на e-mail')
      .should('be.visible')

    cy.get('#exitMessageButton > .exitIcon').click()
  })
})

describe('Функционал авторизации (негативные сценарии)', () => {
  beforeEach(() => {
    cy.visit('https://login.qa.studio')
  })

  it('Правильный логин, неправильный пароль', () => {
    cy.get('#mail')
      .type('german@dolnikov.ru')
      .should('have.value', 'german@dolnikov.ru')

    cy.get('#pass')
      .type('wrong_password')
      .should('have.value', 'wrong_password')

    cy.get('#loginButton').click()

    cy.contains('Такого логина или пароля нет')
      .should('be.visible')

    cy.get('#exitMessageButton > .exitIcon')
      .should('be.visible')
      .click()
  })

  it('Неправильный логин, правильный пароль', () => {
    cy.get('#mail')
      .type('german3@dolnikov.ru')
      .should('have.value', 'german3@dolnikov.ru')

    cy.get('#pass')
      .type('qa_one_love1')
      .should('have.value', 'qa_one_love1')

    cy.get('#loginButton').click()

    cy.contains('Такого логина или пароля нет')
      .should('be.visible')

    cy.get('#exitMessageButton > .exitIcon')
      .should('be.visible')
      .click()
  })

  it('Валидация e-mail: ввод без “@”', () => {
    // а) вводим логин без "@"
    cy.get('#mail')
      .type('germandolnikov.ru')
      .should('have.value', 'germandolnikov.ru')

    // б) вводим правильный пароль
    cy.get('#pass')
      .type('qa_one_love1')
      .should('have.value', 'qa_one_love1')

    // в) кликаем "Войти"
    cy.get('#loginButton').click()

    // г) проверяем текст ошибки валидации e-mail
    cy.contains('Нужно исправить проблему валидации')
      .should('be.visible')
       cy.get('#exitMessageButton > .exitIcon')
      .should('be.visible')
      .click()
  })
})
describe('Тестирование входа на сайт проверка регистра', () => {
  beforeEach(() => {
    cy.visit('https://login.qa.studio')
  })

  it('Успешный вход с валидными данными регистр не соблюдаем', () => {
    cy.get('#mail')
      .type('GerMan@Dolnikov.ru')
      .should('have.value', 'GerMan@Dolnikov.ru')

    cy.get('#pass')
      .type('qa_one_love1')
      .should('have.value', 'qa_one_love1')

    cy.get('#loginButton').click()

    cy.contains('Авторизация прошла успешно')
      .should('be.visible')

    cy.get('#exitMessageButton > .exitIcon').click()
  })
})
